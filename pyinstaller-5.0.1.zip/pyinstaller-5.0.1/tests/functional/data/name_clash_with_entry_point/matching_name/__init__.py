print("Running matching_name/__init__.py as", __name__)
