class Command:
    def create_connection(self, *args, **kwargs):
        return None
