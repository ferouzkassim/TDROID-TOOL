class Plugin:
    def shell(self, cmd, handler=None, timeout=None):
        pass
