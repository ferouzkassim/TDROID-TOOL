0.2.1 (2019-10-14)
--------------------

* Fixes #21: Rename the package name from "adb" to "ppadb"
* Fixes #23: Support push dir to device
* Fixes #25: Don't call logging.basicConfig() in the module


0.1.6 (2019-01-21)
-------------------

* Fix #4 push does not preserve original timestap unlike equiv adb push from command line
* Fix #6 forward_list should also check serial
* Fix #8: adb/command/host/__init__.py can take an exception parsing "devices" data


0.1.0 (2018-06-23)
-------------------

* First release on PyPI.

